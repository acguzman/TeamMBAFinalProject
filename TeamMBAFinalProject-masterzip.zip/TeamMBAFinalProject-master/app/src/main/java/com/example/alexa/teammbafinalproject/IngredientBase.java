package com.example.alexa.teammbafinalproject;

public class IngredientBase {
    public String measuredingredient;

    IngredientBase(String measurement, String ingredient) {
        this.measuredingredient = measuredingredient;
    }
}
